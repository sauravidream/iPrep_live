import 'package:firebase_core/firebase_core.dart';
import 'package:package_info_plus/package_info_plus.dart';

String? selectedAppLanguage;
String? userType;
FirebaseApp? firebaseApp;
PackageInfo? packageInfoP;
String? isVideoPlaying;
