import 'package:flutter/material.dart';

class SignInPage extends StatelessWidget {
  const SignInPage({Key? key}) : super(key: key);
  static const id = 'sign_in_page';
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
