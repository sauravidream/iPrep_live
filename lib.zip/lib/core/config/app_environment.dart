enum AppEnvironment { DEBUG, PROFILE, RELEASE }
